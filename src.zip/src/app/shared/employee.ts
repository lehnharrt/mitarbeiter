export interface Employee {
    mnr: number;
    name: string;
    vorname: string;
    gehalt: number;
}
